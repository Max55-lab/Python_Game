import pygame
import sys
import json
import os
from game import Game
from colors import Colors

# ==============================================================================
# 1. INICIJALIZACIJA I POSTAVKE OKOLIŠA
# ==============================================================================
# Ovdje pokrećemo sve pygame module. Ovo je obavezno prije bilo kakvog korištenja
# grafikona, zvuka ili unosa.
pygame.init()
pygame.mixer.init()  # Posebno inicijaliziramo miksere za zvuk jer nisu dio glavnog inita


# ==============================================================================
# 2. UPRAVLJANJE ZVUKOM (ROBUSTNOST)
# ==============================================================================
# Funkcija start_music() osigurava da glazba svira, ali ne ruši igru ako datoteka
# nedostaje. Ovo je ključno za stabilnost aplikacije (Handling Graceful Degradation).
def start_music():
    try:
        # Osiguravamo točnu putanju do datoteke, bez obzira gdje se pokreće skripta
        base_dir = str(os.path.dirname(__file__))
        music_path = os.path.join(base_dir, "Sounds", "music.ogg")

        # Provjera postoji li datoteka prije pokušaja učitavanja
        if os.path.exists(music_path):
            pygame.mixer.music.load(music_path)
            # -1 znači beskonačna ponavljanja (loop)
            pygame.mixer.music.play(-1)
            # Postavka glasnoće na 40% kako ne bi bila previše glasna odmah
            pygame.mixer.music.set_volume(0.4)
    except (pygame.error, OSError) as e:
        # Ako zvuk ne može učitati (npr. nema kartice ili datoteka), samo ignoriramo grešku
        # Umjesto da korisnik vidi crash, igra nastavlja bez zvuka.
        pass


start_music()

# ==============================================================================
# 3. KONFIGURACIJA EKRANA I FONTOVA
# ==============================================================================
# Definicija fontova za tekst. None koristi standardni pygame font (Freesans).
title_font = pygame.font.Font(None, 60)  # Veliki font za naslove
small_font = pygame.font.Font(None, 35)  # Manji font za UI elemente

# Kreiranje glavnog prozora (Surface) dimenzija 500x620 piksela
# 500px za igru (10 kolona * 30px + margine) + 170px za UI panel
screen = pygame.display.set_mode((500, 620))
pygame.display.set_caption("Python Tetris")

# Clock se koristi za ograničavanje FPS-a (Frames Per Second)
clock = pygame.time.Clock()

# Instanciranje glavne logike igre. Ovdje se odvajamo od grafičkog dijela.
game = Game()

# ==============================================================================
# 4. STANJA IGRE (STATE MACHINE)
# ==============================================================================
# Umjesto složenih 'if-else' uvjeta za svaki dio igre, koristimo "State Machine".
# Svako stanje je konstanta. Ovo olakšava čitanje i održavanje koda.
# 0: Menu, 1: Igranje, 2: Unos imena, 3: Ljestvice, 4: Čišćenje redova, 5: Pauza, 6: Rezultati
MENU, PLAYING, NAME_INPUT, HIGH_SCORES, CLEARING, PAUSE, RESULT_SCREEN = 0, 1, 2, 3, 4, 5, 6

# Početno stanje igre je MENI
game_state = MENU

# Varijable za pomoćne funkcije
clearing_timer = 0  # Vrijeme kada je započelo brisanje redova (za animaciju)
rows_to_flash = []  # Lista redova koji se brišu
player_name = ""  # Privremeno pohranjuje ime igrača
final_score = 0  # Konačni rezultat prije spremanja
final_rank = 0  # Rang igrača na ljestvici

# ==============================================================================
# 5. TIMER ZA LOGIKU IGRE (GAME LOOP)
# ==============================================================================
# Umjesto da igru pokrećemo u 'while' petlji (što može biti neprecizno),
# koristimo pygame događaje (Events) za padanje blokova.
GAME_UPDATE = pygame.USEREVENT
speed = 500  # Početna brzina: blok padne svakih 500ms (0.5 sekundi)
pygame.time.set_timer(GAME_UPDATE, speed)


# ==============================================================================
# 6. POVRŠINSKI SUSTAV (HIGH SCORE SYSTEM)
# ==============================================================================
# Funkcija za učitavanje rezultata iz JSON datoteke.
# Koristi try-except blokove za obradu grešaka (npr. oštećena datoteka).
def load_scores():
    if not os.path.exists("scores.json"):
        return []
    with open("scores.json", "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except (json.JSONDecodeError, IOError):
            # Ako je JSON neispravan, vraćamo praznu listu umjesto crasha
            return []


# Funkcija za spremanje rezultata.
# 1. Učitava postojeće rezultate.
# 2. Dodaje novi rezultat.
# 3. Sortira listu silazno (najveći prvi).
# 4. Sprema natrag u datoteku.
# 5. Vraća rang igrača.
def save_score(name, score):
    scores = load_scores()
    scores.append({"name": name, "score": score})

    # Sortiranje: Lambda funkcija uzima 'score' iz svakog rječnika i sortira obrnuto
    scores = sorted(scores, key=lambda x: x["score"], reverse=True)

    with open("scores.json", "w", encoding="utf-8") as f:
        json.dump(scores, f)

    # Pronalaženje točnog ranga (indeks + 1)
    for rank_index, s in enumerate(scores):
        if s["name"] == name and s["score"] == score:
            return rank_index + 1
    return len(scores)


# ==============================================================================
# 7. GLAVNA PETLJA (MAIN GAME LOOP)
# ==============================================================================
# Ova petlja se vrti beskonačno dok korisnik ne zatvori prozor.
# Sastoji se od 3 faze: 1. Unos događaja (Input), 2. Logika (Update), 3. Crtanje (Render).
while True:
    # --- FAZA 1: DOGAĐAJI (EVENT HANDLING) ---
    for event in pygame.event.get():
        # Provjera za zatvaranje prozora
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        # --- STANJE: MENI (MENU) ---
        if game_state == MENU:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Enter za početak
                    # Resetiramo igru i postavljamo početnu brzinu
                    game.reset()
                    game.set_next_target(load_scores())  # Postavljamo cilj prema trenutnim ljestvicama
                    speed = 500
                    pygame.time.set_timer(GAME_UPDATE, speed)
                    game_state = PLAYING
                elif event.key == pygame.K_h:
                    game_state = HIGH_SCORES  # Prikaz ljestvica

        # --- STANJE: IGRANJE (PLAYING) ---
        elif game_state == PLAYING:
            # Dinamičko ubrzavanje igre
            # Kako razina raste, vrijeme između padanja se smanjuje.
            # Formula: 500ms - (razina * 40ms). Minimum je 100ms.
            new_speed = max(100, 500 - (game.level - 1) * 40)
            if new_speed != speed:
                speed = new_speed
                pygame.time.set_timer(GAME_UPDATE, speed)

            # Obrada tipkovnice
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_p:
                    game_state = PAUSE  # Pauza
                if event.key == pygame.K_LEFT:
                    game.move_left()
                if event.key == pygame.K_RIGHT:
                    game.move_right()
                if event.key == pygame.K_UP:
                    game.rotate()
                if event.key == pygame.K_c:
                    game.hold_block()
                if event.key == pygame.K_SPACE:
                    game.hard_drop()

            # Obrada događaja padanja (GAME_UPDATE)
            if event.type == GAME_UPDATE:
                game.move_down()

            # Provjera cilja (Target Score) - ako je postignut, postavi novi cilj
            if 0 < game.target_score <= game.score:
                game.set_next_target(load_scores())

            # Provjera za pune redove
            if game.get_full_rows():
                rows_to_flash = game.get_full_rows()
                clearing_timer = pygame.time.get_ticks()  # Zabilježi vrijeme za animaciju
                game_state = CLEARING  # Prebaci u stanje čišćenja

            # Provjera kraja igre
            if game.game_over:
                final_score = game.score
                game_state = NAME_INPUT
                player_name = ""

        # --- STANJE: ČIŠĆENJE REDOVA (CLEARING) ---
        # Ovo stanje čeka kratko (300ms) kako bi se prikazala animacija treptanja
        elif game_state == CLEARING:
            if pygame.time.get_ticks() - clearing_timer > 300:
                game.clear_lines()  # Pravo brisanje redova u logici igre
                game_state = PLAYING

        # --- STANJE: UNOS IMENA (NAME_INPUT) ---
        # Omogućuje igraču da unese ime za ljestvice
        elif game_state == NAME_INPUT:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN and player_name:
                    # Spremi rezultat i idi na ekran rezultata
                    final_rank = save_score(player_name, final_score)
                    game_state = RESULT_SCREEN
                elif event.key == pygame.K_BACKSPACE:
                    player_name = player_name[:-1]
                else:
                    # Ograničenje na 10 znakova
                    if len(player_name) < 10:
                        player_name += event.unicode

        # --- STANJE: PAUZA (PAUSE) ---
        elif game_state == PAUSE:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_p:
                game_state = PLAYING

        # --- STANJE: REZULTATI (RESULT_SCREEN) ---
        elif game_state == RESULT_SCREEN:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                game_state = MENU

        # --- STANJE: LJESTVICE (HIGH_SCORES) ---
        elif game_state == HIGH_SCORES:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                game_state = MENU

    # --- FAZA 2 & 3: RENDEROVANJE (RENDERING) ---
    # Prvo očistimo ekran novom bojom (brisanje starog okvira)
    screen.fill(Colors.dark_blue)

    # --- CRtanje MENIJA ---
    if game_state == MENU:
        screen.blit(title_font.render("TETRIS", True, Colors.white), (170, 250))
        screen.blit(small_font.render("ENTER to Play, H for Scores", True, Colors.white), (80, 350))

    # --- CRtanje IGRE (PLAYING, CLEARING, PAUSE) ---
    elif game_state in [PLAYING, CLEARING, PAUSE]:
        # Crtanje UI panela (pozadina za informacije)
        # pygame.draw.rect(surf, color, (x, y, w, h), border_radius=10)
        pygame.draw.rect(screen, Colors.light_blue, (320, 20, 170, 100), 0, 10)  # Score
        pygame.draw.rect(screen, Colors.light_blue, (320, 150, 170, 130), 0, 10)  # Next
        pygame.draw.rect(screen, Colors.light_blue, (320, 320, 170, 130), 0, 10)  # Hold
        pygame.draw.rect(screen, Colors.light_blue, (320, 460, 170, 130), 0, 10)  # Target

        # Tekstualni naslovi panela
        screen.blit(small_font.render("Next", True, Colors.white), (370, 160))
        screen.blit(small_font.render("Hold", True, Colors.white), (370, 330))

        # Prikaz trenutnog rezultata i razine
        screen.blit(small_font.render("Score", True, Colors.white), (370, 30))
        screen.blit(small_font.render(str(game.score), True, Colors.white), (380, 60))
        screen.blit(small_font.render(f"Lvl: {game.level}", True, Colors.white), (365, 90))

        # Prikaz cilja (Target)
        screen.blit(small_font.render("Target:", True, Colors.white), (360, 470))
        if game.target_score > 0:
            screen.blit(small_font.render(game.target_name, True, Colors.yellow), (350, 500))
            screen.blit(small_font.render(str(game.target_score), True, Colors.white), (370, 530))
        else:
            screen.blit(small_font.render("Top player!", True, Colors.green), (350, 500))

        # Pozivanje metode iz Game klase za crtanje svih blokova
        game.draw(screen)

        # --- ANIMACIJA ČIŠĆENJA (CLEARING) ---
        if game_state == CLEARING:
            elapsed = pygame.time.get_ticks() - clearing_timer
            # Izračun transparentnosti (alpha) za efekt blijenja
            alpha = max(0, 255 - int((elapsed / 300) * 255))

            # Kreiranje površine s alfa kanalom za prozirnost
            flash_surf = pygame.Surface((300, 30), pygame.SRCALPHA)
            flash_surf.fill((255, 255, 255, alpha))

            # Crtanje bijelog pravokutnika preko redova koji se brišu
            for row in rows_to_flash:
                screen.blit(flash_surf, (11, row * 30 + 11))

        # Prikaz poruke "PAUSED"
        if game_state == PAUSE:
            screen.blit(title_font.render("PAUSED", True, Colors.white), (170, 300))

    # --- CRtanje EKRANA ZA UNOS IMENA ---
    elif game_state == NAME_INPUT:
        screen.blit(title_font.render("GAME OVER", True, Colors.white), (120, 150))
        screen.blit(small_font.render(f"Score: {final_score}", True, Colors.white), (180, 210))
        screen.blit(small_font.render("Enter Name:", True, Colors.white), (180, 260))
        # Crtanje kursora koji treperi (ako vrijeme prolazi, ali ovdje jednostavan prikaz)
        screen.blit(title_font.render(player_name + "|", True, Colors.yellow), (150, 300))

    # --- CRtanje EKRANA REZULTATA ---
        color = Colors.green if final_rank <= 10 else Colors.red
        msg = "TOP 10!" if final_rank <= 10 else "Not in Top 10"
        screen.blit(title_font.render(msg, True, color), (125, 200))
        screen.blit(small_font.render(f"Your rank: {final_rank}. place", True, Colors.white), (120, 300))
        screen.blit(small_font.render("Press ENTER", True, Colors.light_blue), (170, 400))

    # --- CRtanje EKRANA LJESTVICA (HIGH SCORES) ---
    elif game_state == HIGH_SCORES:
        screen.blit(title_font.render("TOP 10 SCORES", True, Colors.white), (100, 50))

        # Iteracija kroz prvih 10 rezultata iz datoteke
        # enumerate() daje nam i indeks (rang) i podatke o rezultatu
        for score_index, entry in enumerate(load_scores()[:10]):
            # Formatiirani tekst: "1. Ime - 1000"
            txt = small_font.render(f"{score_index + 1}. {entry['name']} - {entry['score']}", True, Colors.white)
            # Pozicioniranje: Y koordinata raste za 40px za svaki red
            screen.blit(txt, (100, 120 + score_index * 40))

        # Poruka za povratak
        screen.blit(small_font.render("ESC to Back", True, Colors.light_blue), (170, 560))

    # --- ZAVRŠETK PETLJE ---
    # 1. Ažuriraj ekran s nacrtanim sadržajem
    pygame.display.update()

    # 2. Ograniči brzinu petlje na 60 FPS (okvira u sekundi)
    # Ovo osigurava da se igra vrti istom brzinom na jakim i slabim računalima
    clock.tick(60)