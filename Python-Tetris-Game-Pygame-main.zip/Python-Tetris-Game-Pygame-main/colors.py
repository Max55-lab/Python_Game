class Colors:
	dark_grey = (26, 31, 40)
	green = (83, 218, 63)
	red =  (234, 20, 28)
	orange =  (254, 72, 25)
	yellow =  (254, 251, 52)
	pink =  (255,29,206)
	cyan = (1, 237, 250)
	blue = (255, 157, 0)
	white = (255, 255, 255)
	dark_blue =  (72, 93, 197)
	light_blue = (59, 85, 162)

	@classmethod
	def get_cell_colors(cls):
		return [cls.dark_grey, cls.green, cls.red, cls.orange, cls.yellow, cls.pink, cls.cyan, cls.blue]
