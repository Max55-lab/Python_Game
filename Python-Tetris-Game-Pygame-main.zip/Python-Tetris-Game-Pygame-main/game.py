from grid import Grid
from blocks import *
import random
import pygame


class Game:
    def __init__(self):
        """
        Inicijalizacija igre.
        Ovdje postavljamo početno stanje svih varijabli koje definiraju tijek igre.
        Razdvajamo logičke komponente (grid, blokovi) od stanja (bodovi, razine).
        """
        self.grid = Grid()

        # Lista svih dostupnih tipova blokova. Koristit ćemo "bagaz" (bag) sustav za fer raspodjelu.
        self.blocks = [IBlock(), JBlock(), LBlock(), OBlock(), SBlock(), TBlock(), ZBlock()]

        # Prvi blok koji će pasti
        self.current_block = self.get_random_block()
        # Blok koji dolazi nakon trenutnog
        self.next_block = self.get_random_block()

        # Blok koji je igrač "zadržao" (Hold funkcija)
        self.held_block = None
        # Zastavica koja sprječava višestruko držanje u jednom padu
        self.can_hold = True

        self.game_over = False
        self.score = 0
        self.lines_cleared = 0
        self.level = 1

        # Vrijeme kada je blok dodirnuo tlo (za lock delay mehaniku)
        self.lock_start_time = 0

        # Varijable za sustav rangiranja (sljedeći cilj)
        self.target_score = 0
        self.target_name = ""

        # --- SIGURNOSNI DIO: Učitavanje zvukova ---
        # Koristimo try-except jer fajlovi možda ne postoje ili pygame audio nije podržan.
        # Ako zvuk ne možemo učitati, postavljamo na None, a ne rušimo cijelu igru.
        try:
            self.rotate_sound = pygame.mixer.Sound("Sounds/rotate.ogg")
            self.clear_sound = pygame.mixer.Sound("Sounds/clear.ogg")
        except (pygame.error, FileNotFoundError):
            # Učitavanje nije uspjelo, nastavit ćemo bez zvuka (graceful degradation)
            self.rotate_sound = None
            self.clear_sound = None

    def set_next_target(self, scores):
        """
        Postavlja sljedeći cilj (target) za igrača na temelju ljestvice.
        Cilj je motivirati igrača da pobijedi sljedećeg igrača na listi.

        Args:
            scores: Lista rječnika s rezultatima i imenima igrača.
        """
        # Sortiramo rezultate od najvišeg prema najnižem
        sorted_scores = sorted(scores, key=lambda x: x["score"], reverse=True)

        # Prolazimo kroz rang listu i tražimo prvog igrača koji ima više bodova od nas
        for s in sorted_scores:
            if s["score"] > self.score:
                self.target_score = s["score"]
                self.target_name = s["name"]
                return

        # Ako smo već na vrhu ili nema igrača iznad nas, cilj brišemo
        self.target_score = 0
        self.target_name = ""

    def get_full_rows(self):
        """
        Pomaže metoda koja vraća indekse redova koji su potpuno popunjeni.
        Koristi list comprehension za čitljivost.
        """
        return [row for row in range(self.grid.num_rows) if self.grid.is_row_full(row)]

    def clear_lines(self):
        """
        Glavna logika za brisanje linija.
        1. Provjerava koje su linije pune.
        2. Briše ih na gridu.
        3. Ažurira bodove, razine i svira zvuk ako je moguće.
        """
        rows_cleared = self.grid.clear_full_rows()

        if rows_cleared > 0:
            # Ako imamo zvuk za brisanje, sviramo ga
            if self.clear_sound:
                self.clear_sound.play()

            # Ažuriraj bodove (100, 300, 500 za 1, 2, 3 linije)
            self.update_score(rows_cleared, 0)

            # Povećaj ukupan broj očišćenih linija
            self.lines_cleared += rows_cleared

            # Povećaj razinu svakih 10 linija (formulacija: razina = (ukupno // 10) + 1)
            self.level = (self.lines_cleared // 10) + 1

        return rows_cleared

    def get_random_block(self):
        """
        Implementira "Bagaz" (Bag) sustav za generiranje blokova.
        Umjesto nasumičnog biranja iz svih 7 tipova (što može dovesti do dugih nizova istih blokova),
        mi imamo "vreću" s točno po jednim od svakog tipa.
        Kada se vreća isprazni, punimo je ponovno.
        Ovo osigurava fer raspodjelu i predvidljivost.
        """
        if len(self.blocks) == 0:
            # Vreća je prazna, ponovno je punimo svim tipovima blokova
            self.blocks = [IBlock(), JBlock(), LBlock(), OBlock(), SBlock(), TBlock(), ZBlock()]

        # Odaberi nasumični blok iz trenutne vreće
        block = random.choice(self.blocks)
        # Makni ga iz vreće da se ne ponovi dok se vreća ne resetira
        self.blocks.remove(block)
        return block

    def get_ghost_row(self):
        """
        Izračunava položaj "duhovnog" (ghost) bloka.
        Ghost blok pokazuje igraču gdje će trenutni blok pasti ako se pusti odmah.
        Ovo je ključno za dobro korisničko iskustvo (UX).
        """
        original_row = self.current_block.row_offset
        ghost_row = original_row

        # Simuliraj pad blokova dok god je sljedeći položaj slobodan i unutar granica
        while True:
            self.current_block.row_offset = ghost_row + 1
            if self.block_inside() and self.block_fits():
                ghost_row += 1
            else:
                break

        # Vrati blok na originalni položaj kako ne bismo promijenili stvarno stanje igre
        self.current_block.row_offset = original_row
        return ghost_row

    def hold_block(self):
        """
        Implementira mehaniku "Hold" (držanje).
        Igrač može zamijeniti trenutni blok s onim koji drži u rezervi.
        Ova akcija je dozvoljena samo jednom po padu bloka.
        """
        if not self.can_hold:
            return

        # Resetiraj lock timer jer igrač vrši akciju
        self.lock_start_time = 0

        if self.held_block is None:
            # Ako nemamo ništa u holdu, spremi trenutni blok i uzmi sljedeći
            self.held_block = self.current_block
            self.current_block = self.next_block
            self.next_block = self.get_random_block()
        else:
            # Ako već imamo blok u holdu, zamijeni ih
            self.current_block, self.held_block = self.held_block, self.current_block

        # Resetiraj položaj novog trenutnog bloka na vrh središta
        self.current_block.row_offset = 0
        self.current_block.column = 3

        # Onemogući ponovno držanje dok se novi blok ne zaključa
        self.can_hold = False

    def update_score(self, lines_cleared, move_down_points):
        """
        Izračunava bodove na temelju očišćenih linija i soft dropa.
        Standardni Tetris bodovanje:
        1 linija = 100, 2 = 300, 3 = 500, 4 = 800 (ovdje nije implementirano 4 jer je rijetko).
        """
        if lines_cleared == 1:
            self.score += 100
        elif lines_cleared == 2:
            self.score += 300
        elif lines_cleared == 3:
            self.score += 500
        # Dodaj bodove za brzi spust (hard/soft drop)
        self.score += move_down_points

    def move_left(self):
        """
        Pomiče blok lijevo.
        Koristi "speculative execution": prvo se pomakne, pa provjeri valjanost.
        Ako je nevaljano, odmah se vraća (rollback).
        """
        self.current_block.move(0, -1)
        if not self.block_inside() or not self.block_fits():
            # Pomak nije valjan, vrati se natrag
            self.current_block.move(0, 1)
        else:
            # Ako je pomak valjan, resetiraj lock timer (igrač još uvijek kontroliira blok)
            self.lock_start_time = 0

    def move_right(self):
        """
        Pomiče blok desno. Isti princip kao move_left.
        """
        self.current_block.move(0, 1)
        if not self.block_inside() or not self.block_fits():
            self.current_block.move(0, -1)
        else:
            self.lock_start_time = 0

    def move_down(self):
        """
        Pomiče blok dolje. Ovdje je implementiran "Lock Delay".
        Kada blok dodirne tlo, ne zaključava se odmah.
        Igrač ima 500ms da ga pomakne (npr. desno ili rotira).
        Ako ne pomakne, blok se zaključa.
        """
        self.current_block.move(1, 0)
        if not self.block_inside() or not self.block_fits():
            # Blok je udario u nešto (tlo ili drugi blok)
            self.current_block.move(-1, 0)  # Vrati se gore

            # Ako je lock_start_time 0, to znači da se tek dodirnulo tlo
            if self.lock_start_time == 0:
                self.lock_start_time = pygame.time.get_ticks()
            # Provjeri je li prošlo više od 500ms od dodira
            elif pygame.time.get_ticks() - self.lock_start_time > 500:
                self.lock_block()
        else:
            # Ako je blok i dalje u zraku, resetiraj timer
            self.lock_start_time = 0

    def hard_drop(self):
        """
        Trenutni spust bloka (Hard Drop).
        Blok skače odmah na dno i odmah se zaključava.
        Ovo je najbrži način za postavljanje bloka.
        """
        # Pomiči dok god je sljedeći položaj slobodan
        while self.block_inside() and self.block_fits():
            self.current_block.move(1, 0)
        # Vrati se za jedan korak gore (jer smo otišli prečesto)
        self.current_block.move(-1, 0)
        # Odmah zaključaj
        self.lock_block()

    def lock_block(self):
        """
        Zaključava trenutni blok na gridu.
        1. Kopira ćelije bloka u grid.
        2. Postavlja novi blok.
        3. Provjerava je li igrač izgubio (Game Over).
        """
        tiles = self.current_block.get_cell_positions()
        # Kopiraj ID trenutnog bloka u grid na odgovarajuće pozicije
        for position in tiles:
            self.grid.grid[position.row][position.column] = self.current_block.id

        # Postavi novi blok
        self.current_block = self.next_block
        self.next_block = self.get_random_block()

        # Resetiraj lock timer
        self.lock_start_time = 0

        # Odmah nakon postavljanja novog bloka, provjeri možda li se on već preklapa s ostalima
        # Ako se preklapa, igra je gotova
        if not self.block_fits():
            self.game_over = True

        # Omogući ponovno držanje za sljedeći pad
        self.can_hold = True

    def reset(self):
        """
        Resetira cijelu igru na početno stanje.
        Koristi se kada igrač izgubi ili želi ponovno početi.
        """
        self.grid.reset()
        self.blocks = [IBlock(), JBlock(), LBlock(), OBlock(), SBlock(), TBlock(), ZBlock()]
        self.current_block = self.get_random_block()
        self.next_block = self.get_random_block()
        self.held_block = None
        self.can_hold = True
        self.game_over = False
        self.score = 0
        self.lines_cleared = 0
        self.level = 1
        self.lock_start_time = 0
        self.target_score = 0
        self.target_name = ""

    def block_fits(self):
        """
        Provjerava dijeli li trenutni blok prostor s već postavljenim blokovima.
        Vraća True ako blok može biti na svojoj poziciji bez sukoba.
        """
        tiles = self.current_block.get_cell_positions()
        for tile in tiles:
            # Ako je bilo koja ćelija zauzeta, blok se ne uklapa
            if not self.grid.is_empty(tile.row, tile.column):
                return False
        return True

    def rotate(self):
        """
        Rotira blok.
        Koristi isti princip kao kretanje: rotiraj -> provjeri -> ako ne valja, poništi.
        Ovo osigurava da blok ne može rotirati unutar zidova ili u drugi blok.
        """
        self.current_block.rotate()
        if not self.block_inside() or not self.block_fits():
            # Rotacija nije valjana, poništi je
            self.current_block.undo_rotation()
        else:
            # Rotacija uspješna, resetiraj lock timer i sviraj zvuk
            self.lock_start_time = 0
            if self.rotate_sound:
                self.rotate_sound.play()

    def block_inside(self):
        """
        Provjerava je li cijeli blok unutar granica grid-a.
        Vraća False ako je bilo koji dio bloka izvan lijeve, desne, gornje ili donje granice.
        """
        tiles = self.current_block.get_cell_positions()
        for tile in tiles:
            if not self.grid.is_inside(tile.row, tile.column):
                return False
        return True

    def draw(self, screen):
        """
        Crta cijelu scenu igre.
        Redoslijed crtanja je bitan: prvo grid, pa ghost, pa trenutni blok, pa UI.
        """
        self.grid.draw(screen)

        # --- 1. Ghost Block (Projekcija) ---
        ghost_row = self.get_ghost_row()
        original_row = self.current_block.row_offset

        # Privremeno postavi blok na ghost poziciju
        self.current_block.row_offset = ghost_row
        ghost_tiles = self.current_block.get_cell_positions()

        # Crtaj samo konturu (debljina 2) za ghost blok
        for tile in ghost_tiles:
            # Izračunaj pravokutnik (x, y, širina, visina)
            # +11 je offset za centriranje unutar ćelije od 30px
            tile_rect = pygame.Rect(tile.column * 30 + 11, tile.row * 30 + 11, 30, 30)
            pygame.draw.rect(screen, (255, 255, 255), tile_rect, 2)

        # Vrati blok na stvarnu poziciju
        self.current_block.row_offset = original_row

        # --- 2. Trenutni blok ---
        self.current_block.draw(screen, 11, 11)

        # --- 3. UI Paneli (Next i Hold) ---
        # Izračunaj središte panela za sljedeći i držani blok
        panel_center_x = 320 + (170 / 2)
        cell_size = 30

        # Pomoćna funkcija za dinamičko centriranje blokova na panelu
        def draw_centered(block, panel_y_center):
            if block is None:
                return

            current_tiles = block.get_cell_positions()
            cols = [t.column for t in current_tiles]
            rows = [t.row for t in current_tiles]

            # Izračunaj širinu i visinu bloka u pikselima
            block_width = (max(cols) - min(cols) + 1) * cell_size
            block_height = (max(rows) - min(rows) + 1) * cell_size

            # Izračunaj poziciju za crtanje tako da se blok centrirano nalazi u panelu
            # Oduzimamo offsete kako bismo poravnali blok prema središtu panela
            draw_x = panel_center_x - (block_width / 2) - (min(cols) * cell_size)
            draw_y = panel_y_center - (block_height / 2) - (min(rows) * cell_size)

            block.draw(screen, draw_x, draw_y)

        # Crtaj blok koji slijedi (Next)
        if self.next_block:
            draw_centered(self.next_block, 230)

        # Crtaj blok koji je držan (Hold)
        if self.held_block:
            draw_centered(self.held_block, 400)